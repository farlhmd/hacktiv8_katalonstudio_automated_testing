<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_CURA Healthcare Service        We Care _b17f12</name>
   <tag></tag>
   <elementGuidId>3d291d67-248e-4bb0-bb44-b6d74d8c442a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.text-vertical-center</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//header[@id='top']/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>6f457fb8-90eb-40de-899c-b572fb7fe8d5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-vertical-center</value>
      <webElementGuid>199fe430-feb6-4fd2-852a-d43fa0063f31</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    </value>
      <webElementGuid>de05758f-e1e4-469d-af6b-6f1246b1bbb8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;top&quot;)/div[@class=&quot;text-vertical-center&quot;]</value>
      <webElementGuid>11d5bc08-44f3-41d8-a744-ca3e1bef4c7a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//header[@id='top']/div</value>
      <webElementGuid>e1e8f072-a5a0-4194-9f56-1f9e45342e07</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Logout'])[1]/following::div[1]</value>
      <webElementGuid>a6b0c260-042f-4a4f-8c6b-6b90b0615fe7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Profile'])[1]/following::div[1]</value>
      <webElementGuid>0f8fd94a-5aa7-4222-b0e6-4299c2330e5c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div</value>
      <webElementGuid>4336aa1d-8816-4ffc-9163-ee363d8391c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    ' or . = '
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    ')]</value>
      <webElementGuid>e9557cd2-eacc-4c00-9fca-9f477a6c7b34</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
